/* RO’Lyfe Pool™ Theme Engine */
const POOL_THEMES={
 classic:{id:"classic",name:"Classic Pool",colors:{background:"#111827",table:"#176b3a",tableDark:"#0b4726",rail:"#5b3a29",railDark:"#382318",cushion:"#0f5132",pocket:"#050505",text:"#fff",accent:"#facc15",secondary:"#d1d5db",player1:"#2563eb",player2:"#dc2626",success:"#22c55e",warning:"#f59e0b",danger:"#ef4444"}},
 rolyfe:{id:"rolyfe",name:"RO’Lyfe",colors:{background:"#07111f",table:"#064e3b",tableDark:"#022c22",rail:"#111827",railDark:"#030712",cushion:"#065f46",pocket:"#000",text:"#f8fafc",accent:"#22c55e",secondary:"#94a3b8",player1:"#22c55e",player2:"#38bdf8",success:"#22c55e",warning:"#facc15",danger:"#ef4444"}},
 emg:{id:"emg",name:"EMG",colors:{background:"#030712",table:"#111827",tableDark:"#020617",rail:"#0f172a",railDark:"#000",cushion:"#1e293b",pocket:"#000",text:"#fff",accent:"#a855f7",secondary:"#64748b",player1:"#a855f7",player2:"#06b6d4",success:"#22c55e",warning:"#facc15",danger:"#f43f5e"}},
 ace:{id:"ace",name:"ACE",colors:{background:"#020617",table:"#0c4a6e",tableDark:"#082f49",rail:"#111827",railDark:"#020617",cushion:"#075985",pocket:"#000",text:"#fff",accent:"#38bdf8",secondary:"#bae6fd",player1:"#38bdf8",player2:"#f97316",success:"#22c55e",warning:"#facc15",danger:"#ef4444"}},
 business:{id:"business",name:"Business",colors:{background:"#0f172a",table:"#14532d",tableDark:"#052e16",rail:"#1e293b",railDark:"#020617",cushion:"#166534",pocket:"#000",text:"#f8fafc",accent:"#f59e0b",secondary:"#94a3b8",player1:"#f59e0b",player2:"#3b82f6",success:"#22c55e",warning:"#f59e0b",danger:"#ef4444"}},
 realestate:{id:"realestate",name:"Real Estate",colors:{background:"#111827",table:"#365314",tableDark:"#1a2e05",rail:"#292524",railDark:"#0c0a09",cushion:"#3f6212",pocket:"#000",text:"#fff",accent:"#84cc16",secondary:"#a8a29e",player1:"#84cc16",player2:"#eab308",success:"#22c55e",warning:"#eab308",danger:"#ef4444"}},
 investor:{id:"investor",name:"Investor",colors:{background:"#020617",table:"#064e3b",tableDark:"#022c22",rail:"#334155",railDark:"#0f172a",cushion:"#047857",pocket:"#000",text:"#f8fafc",accent:"#10b981",secondary:"#94a3b8",player1:"#10b981",player2:"#f97316",success:"#10b981",warning:"#f59e0b",danger:"#ef4444"}},
 sevenfigures:{id:"sevenfigures",name:"7FIGURES",colors:{background:"#09090b",table:"#312e81",tableDark:"#1e1b4b",rail:"#18181b",railDark:"#000",cushion:"#4338ca",pocket:"#000",text:"#fff",accent:"#facc15",secondary:"#a1a1aa",player1:"#facc15",player2:"#8b5cf6",success:"#22c55e",warning:"#facc15",danger:"#ef4444"}},
 midnight:{id:"midnight",name:"Midnight",colors:{background:"#000",table:"#172554",tableDark:"#020617",rail:"#111827",railDark:"#000",cushion:"#1e3a8a",pocket:"#000",text:"#fff",accent:"#60a5fa",secondary:"#64748b",player1:"#60a5fa",player2:"#f472b6",success:"#22c55e",warning:"#facc15",danger:"#fb7185"}},
 neon:{id:"neon",name:"Neon",colors:{background:"#020617",table:"#172554",tableDark:"#020617",rail:"#0f172a",railDark:"#000",cushion:"#1d4ed8",pocket:"#000",text:"#fff",accent:"#22d3ee",secondary:"#c084fc",player1:"#22d3ee",player2:"#f472b6",success:"#4ade80",warning:"#fde047",danger:"#fb7185"}},
 championship:{id:"championship",name:"Championship",colors:{background:"#18181b",table:"#064e3b",tableDark:"#022c22",rail:"#78350f",railDark:"#451a03",cushion:"#047857",pocket:"#000",text:"#fff",accent:"#fbbf24",secondary:"#d4d4d8",player1:"#fbbf24",player2:"#f8fafc",success:"#22c55e",warning:"#f59e0b",danger:"#ef4444"}}
};
const DEFAULT_POOL_THEME="rolyfe";
function getPoolTheme(id=DEFAULT_POOL_THEME){return POOL_THEMES[id]||POOL_THEMES[DEFAULT_POOL_THEME]}
function getPoolThemes(){return Object.values(POOL_THEMES)}
function applyPoolTheme(id=DEFAULT_POOL_THEME){
 const t=getPoolTheme(id),r=document.documentElement,c=t.colors;
 Object.entries({"--pool-bg":c.background,"--pool-table":c.table,"--pool-table-dark":c.tableDark,"--pool-rail":c.rail,"--pool-rail-dark":c.railDark,"--pool-cushion":c.cushion,"--pool-pocket":c.pocket,"--pool-text":c.text,"--pool-accent":c.accent,"--pool-secondary":c.secondary,"--pool-player1":c.player1,"--pool-player2":c.player2,"--pool-success":c.success,"--pool-warning":c.warning,"--pool-danger":c.danger}).forEach(([k,v])=>r.style.setProperty(k,v));
 r.dataset.poolTheme=t.id;return t;
}
function savePoolTheme(id){if(!POOL_THEMES[id])return false;try{localStorage.setItem("rolyfe-pool-theme",id);return true}catch(e){return false}}
function loadPoolTheme(){try{const s=localStorage.getItem("rolyfe-pool-theme");if(s&&POOL_THEMES[s])return s}catch(e){}return DEFAULT_POOL_THEME}
function initializePoolTheme(){return applyPoolTheme(loadPoolTheme())}
function changePoolTheme(id){if(!POOL_THEMES[id])return null;const t=applyPoolTheme(id);savePoolTheme(id);return t}
window.ROLYFE_POOL_THEMES=POOL_THEMES;
window.ROLYFE_POOL_THEME={get:getPoolTheme,list:getPoolThemes,apply:applyPoolTheme,change:changePoolTheme,save:savePoolTheme,load:loadPoolTheme,initialize:initializePoolTheme};
if(typeof document!=="undefined")document.readyState==="loading"?document.addEventListener("DOMContentLoaded",initializePoolTheme):initializePoolTheme();
