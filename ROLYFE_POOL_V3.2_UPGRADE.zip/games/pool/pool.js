/* ============================================================
   RO’LYFE GAMING™ — POOL ENGINE V3.2
   Upgrade: UI integration, theme sync, pause/timer sync,
   shot statistics, challenge/AI status and safer controls.
   ============================================================ */
(function(global){
"use strict";

const CONFIG={
 tableWidth:1000,tableHeight:500,ballRadius:14,friction:.992,rollingResistance:.0008,
 stopVelocity:.045,minPower:.12,maxPower:34,breakPowerMultiplier:1.35,
 collisionRestitution:.94,railRestitution:.88,pocketRadius:34,pocketCaptureRadius:29,
 aiDelay:850,shotSettleDelay:250,playerTime:600,challengeTime:120,aimStep:2.5,
 aimLineLength:240,aiMaxThinkTime:1800,maxVelocity:38,maxBalls:16
};

const state={
 gameType:"8ball",mode:"pvp",aiLevel:1,balls:[],players:[
  {name:"PLAYER 1",score:0,group:null,time:CONFIG.playerTime,fouls:0},
  {name:"PLAYER 2",score:0,group:null,time:CONFIG.playerTime,fouls:0}
 ],currentPlayer:0,shooting:false,aiming:true,cueBall:null,aimAngle:0,aimX:500,aimY:250,
 power:.55,breakShot:true,pocketed:[],foul:false,firstBallHit:null,gameOver:false,
 challenge:false,challengeScore:0,timer:null,animation:null,aiThinking:false,lockOn:false,
 lockedTarget:null,shotCount:0,paused:false,initialized:false
};

const $=s=>document.querySelector(s);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
function vec(x,y){return {x,y}}
function normalize(v){const m=Math.hypot(v.x,v.y)||1;return {x:v.x/m,y:v.y/m}}
function tableEl(){return $("#poolTable")}
function surfaceEl(){return document.querySelector(".table-surface")}
function getTableSize(){const el=surfaceEl()||tableEl();const r=el.getBoundingClientRect();return {w:r.width||CONFIG.tableWidth,h:r.height||CONFIG.tableHeight}}
function scale(){const s=getTableSize();return {x:s.w/CONFIG.tableWidth,y:s.h/CONFIG.tableHeight}}
function message(t){const e=$("#poolMessage");if(e)e.textContent=t}
function updateStats(){
 const names={pvp:"Player vs Player",pvai:"Player vs AI",aivai:"AI vs AI",challenge:"Challenge"};
 const games={8ball:"8-Ball",9ball:"9-Ball",practice:"Practice"};
 const levels=["","START-UP","START-UP+","INVESTOR","INVESTOR+","7FIGURES"];
 if($("#statGame"))$("#statGame").textContent=games[state.gameType]||state.gameType;
 if($("#statMode"))$("#statMode").textContent=names[state.mode]||state.mode;
 if($("#statAI"))$("#statAI").textContent=levels[state.aiLevel]||"START-UP";
 if($("#shotCount"))$("#shotCount").textContent=String(state.shotCount);
 if($("#challengeScore"))$("#challengeScore").textContent=String(state.challengeScore);
 if($("#challengePanel"))$("#challengePanel").hidden=!state.challenge;
}
function updateScoreboard(){
 state.players.forEach((p,i)=>{
  const card=document.querySelector(`.player-card[data-player="${i}"]`);
  if(card)card.classList.toggle("active",i===state.currentPlayer&&!state.gameOver);
  const score=$(`#score${i}`);if(score)score.textContent=String(p.score);
  const group=$(`#group${i}`);if(group)group.textContent=p.group||"Open";
 });
 const turn=$("#turnValue");if(turn)turn.textContent=state.gameOver?"GAME OVER":state.players[state.currentPlayer].name;
}
function updatePowerUI(){if($("#powerFill"))$("#powerFill").style.width=`${Math.round(state.power*100)}%`;if($("#powerValue"))$("#powerValue").textContent=`${Math.round(state.power*100)}%`}
function updateAimLine(){
 const e=$("#aimLine"),s=surfaceEl();if(!e||!s||!state.cueBall){return}
 const sc=scale(),len=CONFIG.aimLineLength*sc.x;
 e.style.left=`${state.cueBall.x*sc.x}px`;e.style.top=`${state.cueBall.y*sc.y}px`;
 e.style.width=`${len}px`;e.style.transform=`translateY(-50%) rotate(${state.aimAngle}rad)`;
 e.style.display=state.shooting||state.gameOver||state.paused?"none":"block";
}
function rack(){
 state.balls=[];state.pocketed=[];state.breakShot=true;state.firstBallHit=null;state.foul=false;
 const add=(n,x,y)=>state.balls.push({id:n,x,y,vx:0,vy:0,pocketed:false});
 add(0,250,250);state.cueBall=state.balls[0];
 if(state.gameType==="9ball"){
  const positions=[];for(let row=0;row<5;row++)for(let col=0;col<=row;col++)positions.push({x:660+row*24,y:250+(col-row/2)*29});
  for(let i=1;i<=9;i++){let p=positions[i-1];add(i,p.x,p.y)}
 }else{
  const positions=[];for(let row=0;row<5;row++)for(let col=0;col<=row;col++)positions.push({x:660+row*24,y:250+(col-row/2)*29});
  for(let i=1;i<=15;i++){let p=positions[i-1];add(i,p.x,p.y)}
 }
 state.aimX=500;state.aimY=250;state.aimAngle=0;render();
}
function render(){
 const layer=$("#ballLayer");if(!layer)return;layer.innerHTML="";
 const sc=scale();
 state.balls.forEach(b=>{if(b.pocketed)return;const el=document.createElement("div");el.className=`ball ${b.id===0?"white cue":""} ${b.id>0?"ball-"+b.id:""}`;el.dataset.ballId=b.id;el.style.left=`${b.x*sc.x}px`;el.style.top=`${b.y*sc.y}px`;layer.appendChild(el)});
 updateAimLine();updatePowerUI();updateScoreboard();updateStats();
}
function resetGame(){
 stopTimer();state.gameOver=false;state.shooting=false;state.aiThinking=false;state.paused=false;state.challenge=state.mode==="challenge";
 state.challengeScore=0;state.shotCount=0;state.players.forEach(p=>{p.score=0;p.group=null;p.fouls=0;p.time=CONFIG.playerTime});
 state.currentPlayer=0;rack();message("Break the rack to begin.");document.body.classList.remove("game-paused");
 if(state.challenge)startTimer(CONFIG.challengeTime);else startTimer(CONFIG.playerTime);
 maybeAI();
}
function startTimer(seconds){
 stopTimer();let remain=seconds;state.players[state.currentPlayer].time=remain;updateTimer(remain);
 state.timer=setInterval(()=>{if(state.paused||state.shooting||state.gameOver||state.aiThinking)return;remain--;state.players[state.currentPlayer].time=remain;updateTimer(remain);if(remain<=0){stopTimer();message("Time expired — turn passes.");switchPlayer(false)}},1000)
}
function updateTimer(v){const e=$("#poolTimer");if(!e)return;v=Math.max(0,v);e.textContent=`${String(Math.floor(v/60)).padStart(2,"0")}:${String(v%60).padStart(2,"0")}`}
function stopTimer(){if(state.timer){clearInterval(state.timer);state.timer=null}}
function switchPlayer(retainTurn=false){
 if(state.gameOver)return;
 state.currentPlayer=state.currentPlayer===0?1:0;state.breakShot=false;state.foul=false;
 updateScoreboard();message(retainTurn?"Continue your turn.":"Turn passed.");startTimer(state.challenge?CONFIG.challengeTime:state.players[state.currentPlayer].time);maybeAI()
}
function setAimAngle(a){state.aimAngle=a;state.aimX=state.cueBall.x+Math.cos(a)*100;state.aimY=state.cueBall.y+Math.sin(a)*100;updateAimLine()}
function aimLeft(){setAimAngle(state.aimAngle-CONFIG.aimStep*Math.PI/180)}
function aimRight(){setAimAngle(state.aimAngle+CONFIG.aimStep*Math.PI/180)}
function setPower(v){state.power=clamp(v,0,1);updatePowerUI()}
function pocketCenters(){
 const s=getTableSize(),w=s.w,h=s.h,pr=CONFIG.pocketCaptureRadius;
 return [{x:0,y:0},{x:w/2,y:0},{x:w,y:0},{x:0,y:h},{x:w/2,y:h},{x:w,y:h}].map(p=>({x:p.x/scale().x,y:p.y/scale().y,r:pr}))
}
function integrate(b,dt){
 b.x+=b.vx*dt;b.y+=b.vy*dt;b.vx*=Math.pow(CONFIG.friction,dt*60);b.vy*=Math.pow(CONFIG.friction,dt*60);
 const v=Math.hypot(b.vx,b.vy);if(v>CONFIG.maxVelocity){b.vx=b.vx/v*CONFIG.maxVelocity;b.vy=b.vy/v*CONFIG.maxVelocity}
}
function rails(b){
 const r=CONFIG.ballRadius,W=CONFIG.tableWidth,H=CONFIG.tableHeight;
 if(b.x<r){b.x=r;b.vx=Math.abs(b.vx)*CONFIG.railRestitution}
 if(b.x>W-r){b.x=W-r;b.vx=-Math.abs(b.vx)*CONFIG.railRestitution}
 if(b.y<r){b.y=r;b.vy=Math.abs(b.vy)*CONFIG.railRestitution}
 if(b.y>H-r){b.y=H-r;b.vy=-Math.abs(b.vy)*CONFIG.railRestitution}
}
function collisions(){
 for(let i=0;i<state.balls.length;i++)for(let j=i+1;j<state.balls.length;j++){
  const a=state.balls[i],b=state.balls[j];if(a.pocketed||b.pocketed)continue;
  let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),min=CONFIG.ballRadius*2;if(!d||d>=min)continue;
  const nx=dx/d,ny=dy/d,overlap=min-d;a.x-=nx*overlap/2;a.y-=ny*overlap/2;b.x+=nx*overlap/2;b.y+=ny*overlap/2;
  const rv=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;if(rv>0)continue;
  const impulse=-(1+CONFIG.collisionRestitution)*rv/2;a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny;
  if(a===state.cueBall||b===state.cueBall){state.firstBallHit=(a===state.cueBall?b:a).id}
 }
}
function pockets(){
 const ps=pocketCenters();
 state.balls.forEach(b=>{if(b.pocketed)return;for(const p of ps){if(Math.hypot(b.x-p.x,b.y-p.y)<=p.r){b.pocketed=true;b.vx=b.vy=0;state.pocketed.push(b.id);if(b.id===0)state.foul=true;else state.players[state.currentPlayer].score++;if(state.challenge&&b.id!==0)state.challengeScore+=b.id===8?50:10;break}}});
}
function anyMoving(){return state.balls.some(b=>!b.pocketed&&Math.hypot(b.vx,b.vy)>CONFIG.stopVelocity)}
function physicsStep(dt){
 if(state.paused)return;
 state.balls.forEach(b=>{if(!b.pocketed)integrate(b,dt)});
 state.balls.forEach(b=>{if(!b.pocketed)rails(b)});
 collisions();pockets();render();
 if(!anyMoving()&&state.shooting)finishShot();
}
function shoot(){
 if(state.shooting||state.gameOver||state.paused||state.aiThinking||!state.cueBall)return;
 state.shooting=true;state.shotCount++;state.firstBallHit=null;state.foul=false;
 const p=CONFIG.minPower+(CONFIG.maxPower-CONFIG.minPower)*state.power;
 const mult=state.breakShot?CONFIG.breakPowerMultiplier:1;
 state.cueBall.vx=Math.cos(state.aimAngle)*p*mult;state.cueBall.vy=Math.sin(state.aimAngle)*p*mult;
 message(`${state.players[state.currentPlayer].name} shoots.`);
 updateStats();
}
function finishShot(){
 state.shooting=false;
 const cuePocketed=state.cueBall.pocketed;
 if(cuePocketed){message("Scratch — cue ball returns to the table.");respotCue();state.players[state.currentPlayer].fouls++}
 if(state.gameType==="8ball"&&state.pocketed.includes(8))evaluate8Ball();
 else if(state.gameType==="9ball"&&state.pocketed.includes(9))endGame(state.currentPlayer,"9-ball pocketed.");
 else if(state.gameType==="practice"){message("Practice shot complete.");}
 else{
  const made=state.pocketed.filter(id=>id!==0).length>0;
  if(cuePocketed||!made)switchPlayer(false);else switchPlayer(true);
 }
 state.pocketed=[];state.firstBallHit=null;state.breakShot=false;render();maybeAI();
}
function respotCue(){const c=state.cueBall;c.pocketed=false;c.x=250;c.y=250;c.vx=c.vy=0}
function evaluate8Ball(){
 const p=state.currentPlayer;
 if(state.players[p].group===null){endGame(p,"8-ball pocketed before group assignment.");return}
 endGame(p,"8-ball pocketed.");
}
function endGame(winner,reason){
 state.gameOver=true;state.shooting=false;stopTimer();updateScoreboard();
 const e=$("#finalScore");if(e)e.textContent=`${state.players[winner].name} wins — ${reason}`;
 const overlay=$("#gameOver");if(overlay)overlay.hidden=false;
 message(`${state.players[winner].name} wins.`);
}
function setGameType(v){if(!["8ball","9ball","practice"].includes(v))return;state.gameType=v;resetGame()}
function setMode(v){if(!["pvp","pvai","aivai","challenge"].includes(v))return;state.mode=v;resetGame()}
function setAILevel(v){state.aiLevel=clamp(Number(v)||1,1,5);resetGame()}
function aiTarget(){
 const legal=state.balls.filter(b=>!b.pocketed&&b.id!==0&&b.id!==8);
 if(state.gameType==="9ball"){const first=legal.sort((a,b)=>a.id-b.id)[0];return first||state.balls.find(b=>b.id===9&&!b.pocketed)}
 return legal[0]||state.balls.find(b=>b.id===8&&!b.pocketed)
}
function aiShoot(){
 if(state.gameOver||state.shooting||state.paused)return;
 const target=aiTarget();if(!target){shoot();return}
 const cue=state.cueBall,angle=Math.atan2(target.y-cue.y,target.x-cue.x);
 const skill=(state.aiLevel-1)/4,error=(1-skill)*.18;
 setAimAngle(angle+(Math.random()-.5)*error);setPower(.45+skill*.42);shoot();
 const status=$("#aiStatus");if(status)status.hidden=false;const txt=$("#aiStatusText");if(txt)txt.textContent=`Level ${state.aiLevel}: target ${target.id}.`;
}
function isAIPlayer(){return state.mode==="aivai"||(state.mode==="pvai"&&state.currentPlayer===1)}
function maybeAI(){
 if(!isAIPlayer()||state.gameOver||state.paused||state.shooting){return}
 state.aiThinking=true;const status=$("#aiStatus");if(status)status.hidden=false;
 const txt=$("#aiStatusText");if(txt)txt.textContent="Analyzing target and shot angle…";
 setTimeout(()=>{state.aiThinking=false;if(!state.gameOver&&!state.paused)isAIPlayer()&&aiShoot()},CONFIG.aiDelay)
}
function togglePause(){
 state.paused=!state.paused;document.body.classList.toggle("game-paused",state.paused);
 if($("#pauseBtn"))$("#pauseBtn").textContent=state.paused?"Resume":"Pause";
 message(state.paused?"Game paused.":"Game resumed.");updateAimLine();
}
function bind(){
 const game=$("#poolGame"),mode=$("#poolMode"),level=$("#poolAILevel"),theme=$("#poolTheme");
 game&&game.addEventListener("change",e=>setGameType(e.target.value));
 mode&&mode.addEventListener("change",e=>setMode(e.target.value));
 level&&level.addEventListener("change",e=>setAILevel(e.target.value));
 theme&&theme.addEventListener("change",e=>window.ROLYFE_POOL_THEME?.change(e.target.value));
 $("#aimLeft")?.addEventListener("click",aimLeft);$("#aimRight")?.addEventListener("click",aimRight);
 $("#shootBtn")?.addEventListener("click",shoot);
 $("#powerUp")?.addEventListener("click",()=>setPower(state.power+.05));$("#powerDown")?.addEventListener("click",()=>setPower(state.power-.05));
 $("#resetPool")?.addEventListener("click",resetGame);$("#newRackBtn")?.addEventListener("click",rack);
 $("#pauseBtn")?.addEventListener("click",togglePause);
 $("#rulesBtn")?.addEventListener("click",()=>{if($("#rulesModal"))$("#rulesModal").hidden=false});
 $("#closeRules")?.addEventListener("click",()=>{if($("#rulesModal"))$("#rulesModal").hidden=true});
 $("#playAgainBtn")?.addEventListener("click",()=>{if($("#gameOver"))$("#gameOver").hidden=true;resetGame()});
 $("#fullscreenBtn")?.addEventListener("click",()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()});
 $("#soundBtn")?.addEventListener("click",()=>document.body.classList.toggle("sound-muted"));
 window.addEventListener("resize",render);
}
function init(){
 if(state.initialized)return;state.initialized=true;
 const theme=window.ROLYFE_POOL_THEME?.load?.()||"rolyfe";
 if($("#poolTheme"))$("#poolTheme").value=theme;
 if($("#poolGame"))$("#poolGame").value=state.gameType;
 if($("#poolMode"))$("#poolMode").value=state.mode;
 if($("#poolAILevel"))$("#poolAILevel").value=String(state.aiLevel);
 window.ROLYFE_POOL_THEME?.apply?.(theme);bind();resetGame();
}
const API={state,config:CONFIG,resetGame,rack,shoot,setPower,aimLeft,aimRight,setMode,setGameType,setAILevel,togglePause};
global.ROLYFE_POOL=API;
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})(window);
